<?php
/*
Plugin Name: MyHome Demo Importer
Description: Demo importer for MyHome theme
Version: 2.0.1
Plugin URI: http://tangibledesign.net
 */
include_once 'includes/class-myhome-importer.php';
$myhome_importer = new My_Home_Importer();
